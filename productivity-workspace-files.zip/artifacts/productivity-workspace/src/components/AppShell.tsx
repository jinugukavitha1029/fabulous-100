import { useState, type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { BarChart3, CalendarDays, CheckSquare2, ChevronRight, CircleUserRound, FolderKanban, LayoutDashboard, Menu, Moon, PanelLeftClose, Plus, Settings, Sparkles, Sun, Timer, X, Target } from 'lucide-react';
import { useProductivity } from '@/context/ProductivityContext';

const navItems = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/tasks', label: 'Tasks', icon: CheckSquare2 },
  { href: '/board', label: 'Board', icon: FolderKanban },
  { href: '/calendar', label: 'Calendar', icon: CalendarDays },
  { href: '/goals', label: 'Goals', icon: Target },
  { href: '/analytics', label: 'Analytics', icon: BarChart3 },
  { href: '/focus', label: 'Focus room', icon: Timer },
];

export function AppShell({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { settings, updateSettings, tasks } = useProductivity();
  const todayCount = tasks.filter((task) => task.status !== 'done' && task.dueDate === new Date().toISOString().slice(0, 10)).length;

  return (
    <div className="grain min-h-[100dvh] bg-background">
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[264px] flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-transform duration-300 lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between px-6 pb-8 pt-7">
          <Link href="/" onClick={() => setMobileOpen(false)} data-testid="link-brand" className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground shadow-lg"><Sparkles size={17} /></span>
            <span><span className="block font-display text-[22px] leading-none">Solstice</span><span className="mt-1 block font-mono-ui text-[9px] uppercase tracking-[.22em] opacity-55">your working day</span></span>
          </Link>
          <button className="rounded-lg p-2 opacity-60 hover:bg-sidebar-accent hover:opacity-100 lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close menu" data-testid="button-close-menu"><X size={18} /></button>
        </div>
        <div className="px-4">
          <button onClick={() => { if (location === '/' || location === '/tasks') window.dispatchEvent(new CustomEvent('solstice:add-task')); else { setLocation('/tasks'); window.setTimeout(() => window.dispatchEvent(new CustomEvent('solstice:add-task')), 80); } }} data-testid="button-quick-add" className="flex w-full items-center justify-between rounded-xl bg-sidebar-primary px-4 py-3 text-sm font-bold text-sidebar-primary-foreground transition-transform hover:-translate-y-0.5 active:translate-y-0">
            <span className="flex items-center gap-2"><Plus size={16} /> New task</span><kbd className="hidden rounded bg-sidebar-primary-foreground/15 px-1.5 py-0.5 font-mono-ui text-[10px] opacity-70 sm:block">N</kbd>
          </button>
        </div>
        <nav className="mt-8 flex-1 px-3" aria-label="Primary navigation">
          <p className="mb-3 px-3 font-mono-ui text-[10px] uppercase tracking-[.18em] opacity-45">Workspace</p>
          <div className="space-y-1">
            {navItems.map(({ href, label, icon: Icon }) => {
              const active = location === href;
              return <Link key={href} href={href} onClick={() => setMobileOpen(false)} data-testid={`link-nav-${label.toLowerCase().replace(' ', '-')}`} className={`group flex items-center justify-between rounded-xl px-3 py-2.5 text-sm transition-colors ${active ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'opacity-70 hover:bg-sidebar-accent/70 hover:opacity-100'}`}>
                <span className="flex items-center gap-3"><Icon size={17} strokeWidth={active ? 2.3 : 1.8} /><span>{label}</span></span>
                {label === 'Tasks' && todayCount > 0 && <span className="rounded-full bg-sidebar-primary px-2 py-0.5 font-mono-ui text-[10px] font-medium text-sidebar-primary-foreground">{todayCount}</span>}
              </Link>;
            })}
          </div>
        </nav>
        <div className="border-t border-sidebar-border p-4">
          <Link href="/settings" onClick={() => setMobileOpen(false)} data-testid="link-nav-settings" className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm opacity-70 hover:bg-sidebar-accent hover:opacity-100 ${location === '/settings' ? 'bg-sidebar-accent opacity-100' : ''}`}><Settings size={17} /> Settings</Link>
          <div className="mt-4 flex items-center gap-3 rounded-xl bg-sidebar-accent/60 p-3">
            <span className="grid size-8 place-items-center rounded-full bg-sidebar-primary font-bold text-sidebar-primary-foreground">M</span>
            <div className="min-w-0 flex-1"><p className="truncate text-xs font-bold">Mara’s workspace</p><p className="mt-0.5 font-mono-ui text-[9px] opacity-50">personal / local</p></div>
            <ChevronRight size={15} className="opacity-40" />
          </div>
        </div>
      </aside>
      {mobileOpen && <button className="fixed inset-0 z-30 bg-foreground/30 backdrop-blur-sm lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation" data-testid="button-nav-overlay" />}
      <div className="min-h-[100dvh] lg:pl-[264px]">
        <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-border/70 bg-background/88 px-5 backdrop-blur-xl sm:px-8 lg:px-11">
          <button className="rounded-xl p-2.5 hover:bg-muted lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu" data-testid="button-open-menu"><Menu size={21} /></button>
          <div className="hidden items-center gap-2 text-xs text-muted-foreground sm:flex"><span className="size-1.5 rounded-full bg-primary" /> Everything stays on this device</div>
          <div className="ml-auto flex items-center gap-2">
            <button onClick={() => updateSettings({ darkMode: !settings.darkMode })} className="rounded-xl p-2.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" aria-label="Toggle theme" data-testid="button-toggle-theme">{settings.darkMode ? <Sun size={18} /> : <Moon size={18} />}</button>
            <Link href="/settings" data-testid="link-profile-settings" className="grid size-9 place-items-center rounded-xl border border-border bg-card text-muted-foreground hover:text-foreground"><CircleUserRound size={18} /></Link>
          </div>
        </header>
        <main className="page-enter px-5 py-7 sm:px-8 sm:py-9 lg:px-11 lg:py-10">{children}</main>
      </div>
    </div>
  );
}