import { useEffect, useState, type FormEvent } from 'react';
import { X } from 'lucide-react';
import { useProductivity, type Task, type TaskPriority, type TaskStatus } from '@/context/ProductivityContext';

type Props = { open: boolean; onClose: () => void; task?: Task | null; initialDate?: string };
const blank = (date = '') => ({ title: '', description: '', projectId: '', status: 'todo' as TaskStatus, priority: 'medium' as TaskPriority, dueDate: date });

export function TaskModal({ open, onClose, task, initialDate }: Props) {
  const { projects, addTask, updateTask, deleteTask } = useProductivity();
  const [form, setForm] = useState(blank(initialDate));
  useEffect(() => {
    if (open) setForm(task ? { title: task.title, description: task.description, projectId: task.projectId, status: task.status, priority: task.priority, dueDate: task.dueDate } : blank(initialDate));
  }, [open, task, initialDate]);
  if (!open) return null;
  const set = (key: keyof typeof form, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!form.title.trim()) return;
    if (task) updateTask(task.id, form);
    else addTask({ ...form, projectId: form.projectId || projects[0]?.id || '' });
    onClose();
  };
  return <div className="fixed inset-0 z-50 grid place-items-center bg-foreground/35 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={task ? 'Edit task' : 'New task'} data-testid="modal-task">
    <form onSubmit={submit} className="modal-in max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-3xl border border-border bg-card p-6 shadow-2xl sm:p-8">
      <div className="mb-7 flex items-start justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-primary">{task ? 'Refine the plan' : 'Make it real'}</p><h2 className="mt-1 font-display text-3xl">{task ? 'Edit task' : 'New task'}</h2></div><button type="button" onClick={onClose} className="rounded-xl p-2 text-muted-foreground hover:bg-muted hover:text-foreground" aria-label="Close task form" data-testid="button-close-task-modal"><X size={20} /></button></div>
      <div className="space-y-5">
        <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Task title</span><input autoFocus required value={form.title} onChange={(e) => set('title', e.target.value)} placeholder="What deserves your attention?" className="w-full rounded-xl border border-input bg-background px-4 py-3 text-sm transition-colors placeholder:text-muted-foreground/65 focus:border-primary" data-testid="input-task-title" /></label>
        <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-muted-foreground">A little context</span><textarea value={form.description} onChange={(e) => set('description', e.target.value)} rows={3} placeholder="The useful detail you’ll want when you return to this..." className="w-full resize-none rounded-xl border border-input bg-background px-4 py-3 text-sm placeholder:text-muted-foreground/65 focus:border-primary" data-testid="input-task-description" /></label>
        <div className="grid gap-4 sm:grid-cols-2">
          <label><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Project</span><select value={form.projectId} onChange={(e) => set('projectId', e.target.value)} className="w-full rounded-xl border border-input bg-background px-3 py-3 text-sm focus:border-primary" data-testid="select-task-project"><option value="">No project</option>{projects.map((project) => <option key={project.id} value={project.id}>{project.name}</option>)}</select></label>
          <label><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Due date</span><input type="date" value={form.dueDate} onChange={(e) => set('dueDate', e.target.value)} className="w-full rounded-xl border border-input bg-background px-3 py-3 text-sm focus:border-primary" data-testid="input-task-due-date" /></label>
          <label><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Priority</span><select value={form.priority} onChange={(e) => set('priority', e.target.value)} className="w-full rounded-xl border border-input bg-background px-3 py-3 text-sm focus:border-primary" data-testid="select-task-priority"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="urgent">Urgent</option></select></label>
          <label><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Status</span><select value={form.status} onChange={(e) => set('status', e.target.value)} className="w-full rounded-xl border border-input bg-background px-3 py-3 text-sm focus:border-primary" data-testid="select-task-status"><option value="todo">To do</option><option value="in-progress">In progress</option><option value="done">Done</option></select></label>
        </div>
      </div>
      <div className="mt-8 flex items-center justify-between gap-3 border-t border-border pt-5">{task ? <button type="button" onClick={() => { if (window.confirm('Delete this task?')) { deleteTask(task.id); onClose(); } }} className="text-sm font-bold text-destructive hover:underline" data-testid="button-delete-task">Delete task</button> : <span /> }<div className="flex gap-2"><button type="button" onClick={onClose} className="rounded-xl px-4 py-2.5 text-sm font-bold text-muted-foreground hover:bg-muted" data-testid="button-cancel-task">Cancel</button><button type="submit" className="rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground shadow-sm hover:brightness-105" data-testid="button-save-task">{task ? 'Save changes' : 'Add task'}</button></div></div>
    </form>
  </div>;
}