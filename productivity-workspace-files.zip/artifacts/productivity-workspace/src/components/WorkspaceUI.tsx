import { Check, Circle, Clock3, MoreHorizontal } from 'lucide-react';
import type { ReactNode } from 'react';
import { useProductivity, type Task } from '@/context/ProductivityContext';

export const formatDate = (date: string) => date ? new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(new Date(`${date}T12:00:00`)) : 'No date';
export const isToday = (date: string) => date === new Date().toISOString().slice(0, 10);

export function PageIntro({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">{eyebrow}</p><h1 className="mt-2 font-display text-4xl leading-[.95] tracking-tight sm:text-5xl">{title}</h1><p className="mt-3 max-w-xl text-sm leading-6 text-muted-foreground">{description}</p></div>{action}</div>;
}

export function StatCard({ label, value, detail, tone = 'default' }: { label: string; value: string | number; detail: string; tone?: 'default' | 'warm' | 'teal' }) {
  return <div className={`soft-shadow rounded-2xl border border-card-border p-5 ${tone === 'warm' ? 'bg-accent/10' : tone === 'teal' ? 'bg-primary/8' : 'bg-card'}`}><p className="font-mono-ui text-[10px] uppercase tracking-[.16em] text-muted-foreground">{label}</p><p className="mt-4 font-display text-4xl">{value}</p><p className="mt-2 text-xs text-muted-foreground">{detail}</p></div>;
}

const priorityStyles = { low: 'bg-muted text-muted-foreground', medium: 'bg-chart-3/15 text-foreground', high: 'bg-accent/20 text-foreground', urgent: 'bg-destructive/12 text-destructive' };
const priorityLabel = { low: 'Low', medium: 'Medium', high: 'High', urgent: 'Urgent' };

export function PriorityPill({ priority }: { priority: Task['priority'] }) {
  return <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${priorityStyles[priority]}`}>{priorityLabel[priority]}</span>;
}

export function TaskRow({ task, onEdit, compact = false }: { task: Task; onEdit: (task: Task) => void; compact?: boolean }) {
  const { updateTask } = useProductivity();
  const project = useProductivity().projects.find((item) => item.id === task.projectId);
  return <div className={`group flex items-start gap-3 rounded-2xl border border-border/70 bg-card p-4 transition-all hover:border-primary/40 hover:shadow-sm ${task.status === 'done' ? 'opacity-65' : ''}`} data-testid={`row-task-${task.id}`}>
    <button onClick={() => updateTask(task.id, { status: task.status === 'done' ? 'todo' : 'done' })} className={`mt-0.5 grid size-5 shrink-0 place-items-center rounded-full border-2 transition-colors ${task.status === 'done' ? 'border-primary bg-primary text-primary-foreground' : 'border-muted-foreground/30 hover:border-primary'}`} aria-label={task.status === 'done' ? 'Mark task incomplete' : 'Mark task complete'} data-testid={`button-complete-task-${task.id}`}>{task.status === 'done' && <Check size={12} strokeWidth={3} />}</button>
    <button className="min-w-0 flex-1 text-left" onClick={() => onEdit(task)} data-testid={`button-edit-task-${task.id}`}><p className={`text-sm font-bold ${task.status === 'done' ? 'line-through' : ''}`}>{task.title}</p>{!compact && task.description && <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{task.description}</p>}<div className="mt-3 flex flex-wrap items-center gap-2">{project && <span className="flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground"><span className="size-1.5 rounded-full" style={{ backgroundColor: project.color }} />{project.name}</span>}<span className="flex items-center gap-1 text-[10px] text-muted-foreground"><Clock3 size={11} />{formatDate(task.dueDate)}</span>{!compact && <PriorityPill priority={task.priority} />}</div></button>
    <button onClick={() => onEdit(task)} aria-label="More task options" className="rounded-lg p-1.5 text-muted-foreground opacity-0 transition-opacity hover:bg-muted group-hover:opacity-100" data-testid={`button-task-options-${task.id}`}><MoreHorizontal size={17} /></button>
  </div>;
}

export function EmptyState({ title, description, action }: { title: string; description: string; action?: ReactNode }) {
  return <div className="rounded-2xl border border-dashed border-border bg-card/50 px-6 py-14 text-center"><div className="mx-auto grid size-11 place-items-center rounded-2xl bg-primary/10 text-primary"><Circle size={18} /></div><h3 className="mt-4 font-display text-2xl">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">{description}</p>{action && <div className="mt-5">{action}</div>}</div>;
}

export function SectionHeader({ title, action }: { title: string; action?: ReactNode }) {
  return <div className="mb-4 flex items-center justify-between"><h2 className="font-display text-2xl">{title}</h2>{action}</div>;
}