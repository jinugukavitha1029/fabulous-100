import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ErrorBoundary } from '@/components/error-boundary';
import { AppShell } from '@/components/AppShell';
import { ProductivityProvider } from '@/context/ProductivityContext';
import Dashboard from '@/pages/Dashboard';
import Tasks from '@/pages/Tasks';
import Board from '@/pages/Board';
import Calendar from '@/pages/Calendar';
import Goals from '@/pages/Goals';
import Analytics from '@/pages/Analytics';
import Focus from '@/pages/Focus';
import Settings from '@/pages/Settings';
import NotFound from '@/pages/not-found';
import { Route, Router as WouterRouter, Switch, useLocation } from 'wouter';

const queryClient = new QueryClient();

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return <RoutedErrorBoundary><AppShell><Switch>
    <Route path="/" component={Dashboard} />
    <Route path="/tasks" component={Tasks} />
    <Route path="/board" component={Board} />
    <Route path="/calendar" component={Calendar} />
    <Route path="/goals" component={Goals} />
    <Route path="/analytics" component={Analytics} />
    <Route path="/focus" component={Focus} />
    <Route path="/settings" component={Settings} />
    <Route component={NotFound} />
  </Switch></AppShell></RoutedErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><ProductivityProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter></ProductivityProvider></TooltipProvider></QueryClientProvider>;
}

export default App;