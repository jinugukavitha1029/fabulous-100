import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export type TaskStatus = 'todo' | 'in-progress' | 'done';
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';

export type Task = {
  id: string;
  title: string;
  description: string;
  projectId: string;
  status: TaskStatus;
  priority: TaskPriority;
  dueDate: string;
  createdAt: string;
  completedAt?: string;
};

export type Project = { id: string; name: string; color: string };
export type Goal = { id: string; title: string; description: string; target: number; current: number; dueDate: string; color: string };
export type Settings = { darkMode: boolean; workDuration: number; breakDuration: number };
export type ProductivityState = { tasks: Task[]; projects: Project[]; goals: Goal[]; settings: Settings; sessions: Record<string, number> };

type ProductivityContextValue = ProductivityState & {
  addTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  updateTask: (id: string, patch: Partial<Task>) => void;
  reorderTask: (id: string, status: TaskStatus, beforeId?: string) => void;
  deleteTask: (id: string) => void;
  addProject: (project: Omit<Project, 'id'>) => void;
  addGoal: (goal: Omit<Goal, 'id'>) => void;
  updateGoal: (id: string, patch: Partial<Goal>) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  recordSession: () => void;
  resetAll: () => void;
};

const STORAGE_KEY = 'solstice-productivity-v1';
const isoDay = (offset = 0) => {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() + offset);
  return date.toISOString().slice(0, 10);
};

const demoState = (): ProductivityState => ({
  projects: [
    { id: 'studio', name: 'Studio refresh', color: '#2f8f83' },
    { id: 'writing', name: 'Writing practice', color: '#e58b70' },
    { id: 'life', name: 'Life admin', color: '#d4ad4d' },
  ],
  tasks: [
    { id: 'task-1', title: 'Shape the new project brief', description: 'Turn the loose notes into a one-page brief for Monday.', projectId: 'studio', status: 'in-progress', priority: 'high', dueDate: isoDay(0), createdAt: isoDay(-3) },
    { id: 'task-2', title: 'Outline the essay opening', description: 'Find the first image and write the first 400 words.', projectId: 'writing', status: 'todo', priority: 'medium', dueDate: isoDay(1), createdAt: isoDay(-2) },
    { id: 'task-3', title: 'Book dentist appointment', description: 'Call after lunch and choose a morning slot.', projectId: 'life', status: 'todo', priority: 'low', dueDate: isoDay(3), createdAt: isoDay(-1) },
    { id: 'task-4', title: 'Clear the downloads folder', description: 'Archive old references and remove duplicates.', projectId: 'life', status: 'done', priority: 'low', dueDate: isoDay(-1), createdAt: isoDay(-5), completedAt: isoDay(-1) },
    { id: 'task-5', title: 'Send launch check-in', description: 'Share the latest timeline with the small team.', projectId: 'studio', status: 'done', priority: 'urgent', dueDate: isoDay(-2), createdAt: isoDay(-7), completedAt: isoDay(-2) },
    { id: 'task-6', title: 'Collect three references', description: 'Save the pieces that make the visual direction feel warm.', projectId: 'studio', status: 'done', priority: 'medium', dueDate: isoDay(-4), createdAt: isoDay(-8), completedAt: isoDay(-4) },
  ],
  goals: [
    { id: 'goal-1', title: 'Make space for deep work', description: 'Complete focused sessions before opening the inbox.', target: 20, current: 12, dueDate: isoDay(18), color: '#2f8f83' },
    { id: 'goal-2', title: 'Publish the first draft', description: 'Move the essay from notes into the world.', target: 5, current: 3, dueDate: isoDay(25), color: '#e58b70' },
  ],
  settings: { darkMode: false, workDuration: 25, breakDuration: 5 },
  sessions: { [isoDay(-6)]: 2, [isoDay(-5)]: 3, [isoDay(-4)]: 1, [isoDay(-3)]: 2, [isoDay(-2)]: 4, [isoDay(-1)]: 2, [isoDay(0)]: 1 },
});

const readState = (): ProductivityState => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) as ProductivityState : demoState();
  } catch {
    return demoState();
  }
};

const ProductivityContext = createContext<ProductivityContextValue | null>(null);

export function ProductivityProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<ProductivityState>(() => readState());

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    document.documentElement.classList.toggle('dark', state.settings.darkMode);
  }, [state]);

  const value = useMemo<ProductivityContextValue>(() => ({
    ...state,
    addTask: (task) => setState((current) => ({ ...current, tasks: [...current.tasks, { ...task, id: `task-${Date.now()}`, createdAt: new Date().toISOString().slice(0, 10) }] })),
    updateTask: (id, patch) => setState((current) => ({
      ...current,
      tasks: current.tasks.map((task) => {
        if (task.id !== id) return task;
        const next = { ...task, ...patch };
        if (patch.status === 'done' && !task.completedAt) next.completedAt = new Date().toISOString().slice(0, 10);
        if (patch.status && patch.status !== 'done') next.completedAt = undefined;
        return next;
      }),
    })),
    reorderTask: (id, status, beforeId) => setState((current) => {
      const moving = current.tasks.find((task) => task.id === id);
      if (!moving) return current;
      const remaining = current.tasks.filter((task) => task.id !== id);
      const next = { ...moving, status, ...(status === 'done' && !moving.completedAt ? { completedAt: todayKey() } : {}), ...(status !== 'done' ? { completedAt: undefined } : {}) };
      const targetIndex = beforeId ? remaining.findIndex((task) => task.id === beforeId) : -1;
      if (targetIndex < 0) return { ...current, tasks: [...remaining, next] };
      remaining.splice(targetIndex, 0, next);
      return { ...current, tasks: remaining };
    }),
    deleteTask: (id) => setState((current) => ({ ...current, tasks: current.tasks.filter((task) => task.id !== id) })),
    addProject: (project) => setState((current) => ({ ...current, projects: [...current.projects, { ...project, id: `project-${Date.now()}` }] })),
    addGoal: (goal) => setState((current) => ({ ...current, goals: [...current.goals, { ...goal, id: `goal-${Date.now()}` }] })),
    updateGoal: (id, patch) => setState((current) => ({ ...current, goals: current.goals.map((goal) => goal.id === id ? { ...goal, ...patch } : goal) })),
    updateSettings: (patch) => setState((current) => ({ ...current, settings: { ...current.settings, ...patch } })),
    recordSession: () => setState((current) => ({ ...current, sessions: { ...current.sessions, [isoDay()]: (current.sessions[isoDay()] ?? 0) + 1 } })),
    resetAll: () => setState((current) => ({ ...current, tasks: [], projects: [], goals: [], sessions: {} })),
  }), [state]);

  return <ProductivityContext.Provider value={value}>{children}</ProductivityContext.Provider>;
}

export function useProductivity() {
  const context = useContext(ProductivityContext);
  if (!context) throw new Error('useProductivity must be used inside ProductivityProvider');
  return context;
}

export const todayKey = () => isoDay();