import { useEffect, useMemo, useState } from 'react';
import { Plus, Search, X } from 'lucide-react';
import { useProductivity, type Task } from '@/context/ProductivityContext';
import { EmptyState, PageIntro, TaskRow } from '@/components/WorkspaceUI';
import { TaskModal } from '@/components/TaskModal';

export default function Tasks() {
  const { tasks, projects } = useProductivity();
  const [modal, setModal] = useState<{ open: boolean; task?: Task | null }>({ open: false });
  const [query, setQuery] = useState('');
  const [project, setProject] = useState('all');
  const [status, setStatus] = useState('all');
  const [priority, setPriority] = useState('all');
  const [sort, setSort] = useState('due');
  useEffect(() => {
    const open = () => setModal({ open: true });
    window.addEventListener('solstice:add-task', open);
    return () => window.removeEventListener('solstice:add-task', open);
  }, []);
  const filtered = useMemo(() => tasks.filter((task) => (!query || `${task.title} ${task.description}`.toLowerCase().includes(query.toLowerCase())) && (project === 'all' || task.projectId === project) && (status === 'all' || task.status === status) && (priority === 'all' || task.priority === priority)).sort((a, b) => sort === 'priority' ? ['urgent', 'high', 'medium', 'low'].indexOf(a.priority) - ['urgent', 'high', 'medium', 'low'].indexOf(b.priority) : a.dueDate.localeCompare(b.dueDate)), [tasks, query, project, status, priority, sort]);
  const activeFilter = project !== 'all' || status !== 'all' || priority !== 'all' || query;
  const clear = () => { setProject('all'); setStatus('all'); setPriority('all'); setQuery(''); };
  return <div>
    <PageIntro eyebrow="The open loop" title="Tasks" description="A place to hold the details, then get out of their way." action={<button onClick={() => setModal({ open: true })} className="flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground" data-testid="button-add-task"><Plus size={17} /> New task</button>} />
    <div className="mb-6 rounded-2xl border border-border bg-card p-3 sm:p-4"><div className="flex flex-col gap-3 xl:flex-row"><label className="flex min-w-0 flex-1 items-center gap-2 rounded-xl bg-muted px-3"><Search size={16} className="shrink-0 text-muted-foreground" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search your tasks..." className="w-full bg-transparent py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none" data-testid="input-task-search" /></label><div className="grid grid-cols-2 gap-2 sm:grid-cols-4"><select value={project} onChange={(e) => setProject(e.target.value)} className="rounded-xl border border-input bg-background px-3 py-2 text-xs font-bold" data-testid="select-filter-project"><option value="all">All projects</option>{projects.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select><select value={status} onChange={(e) => setStatus(e.target.value)} className="rounded-xl border border-input bg-background px-3 py-2 text-xs font-bold" data-testid="select-filter-status"><option value="all">All status</option><option value="todo">To do</option><option value="in-progress">In progress</option><option value="done">Done</option></select><select value={priority} onChange={(e) => setPriority(e.target.value)} className="rounded-xl border border-input bg-background px-3 py-2 text-xs font-bold" data-testid="select-filter-priority"><option value="all">All priority</option><option value="urgent">Urgent</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select><select value={sort} onChange={(e) => setSort(e.target.value)} className="rounded-xl border border-input bg-background px-3 py-2 text-xs font-bold" data-testid="select-sort-tasks"><option value="due">Sort: due date</option><option value="priority">Sort: priority</option></select></div></div>{activeFilter && <button onClick={clear} className="mt-3 flex items-center gap-1 text-xs font-bold text-primary hover:underline" data-testid="button-clear-filters"><X size={13} /> Clear filters</button>}</div>
    {filtered.length ? <div className="space-y-3">{filtered.map((task) => <TaskRow key={task.id} task={task} onEdit={(selected) => setModal({ open: true, task: selected })} />)}</div> : <EmptyState title="Nothing matches that view" description="Try a different filter, or make room for a new idea." action={<button onClick={() => setModal({ open: true })} className="rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground" data-testid="button-empty-task">Add task</button>} />}
    <TaskModal open={modal.open} task={modal.task} onClose={() => setModal({ open: false })} />
  </div>;
}