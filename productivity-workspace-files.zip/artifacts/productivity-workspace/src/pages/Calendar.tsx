import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { useProductivity, type Task } from '@/context/ProductivityContext';
import { formatDate, PageIntro, TaskRow, EmptyState } from '@/components/WorkspaceUI';
import { TaskModal } from '@/components/TaskModal';

const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const keyFor = (date: Date) => date.toISOString().slice(0, 10);

export default function Calendar() {
  const { tasks } = useProductivity();
  const [cursor, setCursor] = useState(() => new Date());
  const [selected, setSelected] = useState(keyFor(new Date()));
  const [modal, setModal] = useState<{ open: boolean; task?: Task | null; date?: string }>({ open: false });
  const year = cursor.getFullYear(); const month = cursor.getMonth();
  const first = new Date(year, month, 1); const start = new Date(year, month, 1 - first.getDay());
  const days = useMemo(() => Array.from({ length: 42 }, (_, index) => { const d = new Date(start); d.setDate(start.getDate() + index); return d; }), [year, month]);
  const selectedTasks = tasks.filter((task) => task.dueDate === selected);
  return <div>
    <PageIntro eyebrow="Time with edges" title="Calendar" description="See what’s asking for a day, without letting the day become a cage." action={<button onClick={() => setModal({ open: true, date: selected })} className="flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground" data-testid="button-calendar-add-task"><Plus size={17} /> Add on {formatDate(selected)}</button>} />
    <div className="grid gap-8 xl:grid-cols-[1.45fr_.55fr]">
      <section className="rounded-2xl border border-border bg-card p-4 sm:p-6"><div className="mb-6 flex items-center justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.16em] text-primary">Month view</p><h2 className="mt-1 font-display text-3xl">{cursor.toLocaleDateString('en', { month: 'long', year: 'numeric' })}</h2></div><div className="flex gap-1"><button onClick={() => setCursor(new Date(year, month - 1, 1))} className="rounded-xl p-2 hover:bg-muted" aria-label="Previous month" data-testid="button-calendar-prev"><ChevronLeft size={18} /></button><button onClick={() => setCursor(new Date())} className="rounded-xl px-3 text-xs font-bold hover:bg-muted" data-testid="button-calendar-today">Today</button><button onClick={() => setCursor(new Date(year, month + 1, 1))} className="rounded-xl p-2 hover:bg-muted" aria-label="Next month" data-testid="button-calendar-next"><ChevronRight size={18} /></button></div></div><div className="grid grid-cols-7 border-l border-t border-border">{dayNames.map((day) => <div key={day} className="border-b border-r border-border px-1 py-2 text-center font-mono-ui text-[9px] uppercase tracking-wider text-muted-foreground sm:px-2">{day}</div>)}{days.map((day) => { const key = keyFor(day); const dayTasks = tasks.filter((task) => task.dueDate === key); const inMonth = day.getMonth() === month; return <button key={key} onClick={() => setSelected(key)} className={`min-h-[76px] border-b border-r border-border p-1.5 text-left transition-colors sm:min-h-[100px] sm:p-2 ${inMonth ? 'bg-card' : 'bg-muted/35 text-muted-foreground/50'} ${selected === key ? 'bg-primary/10 ring-2 ring-inset ring-primary' : 'hover:bg-muted/60'}`} data-testid={`calendar-day-${key}`}><span className={`grid size-6 place-items-center rounded-full font-mono-ui text-[10px] ${key === keyFor(new Date()) ? 'bg-accent text-accent-foreground' : ''}`}>{day.getDate()}</span><div className="mt-1 space-y-1">{dayTasks.slice(0, 2).map((task) => <span key={task.id} className={`block truncate rounded px-1 py-0.5 text-[9px] font-bold ${task.status === 'done' ? 'bg-primary/10 text-primary line-through' : 'bg-secondary text-secondary-foreground'}`}>{task.title}</span>)}{dayTasks.length > 2 && <span className="block px-1 font-mono-ui text-[9px] text-muted-foreground">+{dayTasks.length - 2} more</span>}</div></button>; })}</div></section>
      <section><div className="mb-4"><p className="font-mono-ui text-[10px] uppercase tracking-[.16em] text-primary">Selected day</p><h2 className="mt-1 font-display text-3xl">{formatDate(selected)}</h2></div>{selectedTasks.length ? <div className="space-y-3">{selectedTasks.map((task) => <TaskRow key={task.id} task={task} compact onEdit={(item) => setModal({ open: true, task: item })} />)}</div> : <EmptyState title="No plans here yet" description="Keep this space open, or give the day one clear intention." action={<button onClick={() => setModal({ open: true, date: selected })} className="rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground" data-testid="button-selected-day-add">Add a task</button>} />}</section>
    </div><TaskModal open={modal.open} task={modal.task} initialDate={modal.date} onClose={() => setModal({ open: false })} />
  </div>;
}