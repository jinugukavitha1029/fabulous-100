import { useMemo, useState } from 'react';
import { GripVertical, Plus } from 'lucide-react';
import { useProductivity, type Task, type TaskStatus } from '@/context/ProductivityContext';
import { PageIntro, PriorityPill } from '@/components/WorkspaceUI';
import { TaskModal } from '@/components/TaskModal';

const columns: { id: TaskStatus; label: string; hint: string; color: string }[] = [
  { id: 'todo', label: 'To do', hint: 'On the horizon', color: '#d4ad4d' },
  { id: 'in-progress', label: 'In progress', hint: 'In your hands', color: '#e58b70' },
  { id: 'done', label: 'Done', hint: 'A little lighter', color: '#2f8f83' },
];

export default function Board() {
  const { tasks, updateTask, reorderTask, projects } = useProductivity();
  const [dragId, setDragId] = useState<string | null>(null);
  const [modal, setModal] = useState<{ open: boolean; task?: Task | null; status?: TaskStatus }>({ open: false });
  const [dragOver, setDragOver] = useState<TaskStatus | null>(null);
  const [dropTarget, setDropTarget] = useState<string | null>(null);
  const byStatus = useMemo(() => columns.reduce((acc, column) => ({ ...acc, [column.id]: tasks.filter((task) => task.status === column.id) }), {} as Record<TaskStatus, Task[]>), [tasks]);
  const openNew = (status: TaskStatus) => setModal({ open: true, status });
  return <div>
    <PageIntro eyebrow="A wider view" title="Board" description="Move work by feel. The board is a separate space for seeing momentum, not managing every detail." />
    <div className="grid gap-5 xl:grid-cols-3">{columns.map((column) => <section key={column.id} onDragOver={(e) => { e.preventDefault(); setDragOver(column.id); }} onDragLeave={() => setDragOver(null)} onDrop={(e) => { e.preventDefault(); if (dragId) reorderTask(dragId, column.id); setDragId(null); setDragOver(null); setDropTarget(null); }} className={`min-h-[430px] rounded-2xl border bg-muted/45 p-3 transition-colors ${dragOver === column.id ? 'border-primary bg-primary/8' : 'border-border'}`} data-testid={`column-${column.id}`}>
      <div className="flex items-center justify-between px-2 pb-4 pt-1"><div className="flex items-center gap-2"><span className="size-2 rounded-full" style={{ backgroundColor: column.color }} /><div><h2 className="text-sm font-bold">{column.label}</h2><p className="font-mono-ui text-[9px] uppercase tracking-wider text-muted-foreground">{column.hint}</p></div><span className="ml-1 rounded-full bg-background px-2 py-0.5 font-mono-ui text-[10px] text-muted-foreground">{byStatus[column.id].length}</span></div><button onClick={() => openNew(column.id)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-background hover:text-foreground" aria-label={`Add task to ${column.label}`} data-testid={`button-add-${column.id}`}><Plus size={16} /></button></div>
      <div className="space-y-3">{byStatus[column.id].map((task) => { const project = projects.find((item) => item.id === task.projectId); return <article draggable onDragStart={() => setDragId(task.id)} onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); setDragOver(column.id); setDropTarget(task.id); }} onDrop={(e) => { e.preventDefault(); e.stopPropagation(); if (dragId && dragId !== task.id) reorderTask(dragId, column.id, task.id); setDragId(null); setDragOver(null); setDropTarget(null); }} onDragEnd={() => { setDragId(null); setDragOver(null); setDropTarget(null); }} key={task.id} className={`cursor-grab rounded-2xl border border-border bg-card p-4 shadow-sm transition-transform active:cursor-grabbing active:scale-[.98] ${dragId === task.id ? 'opacity-40' : ''} ${dropTarget === task.id ? 'border-primary' : ''}`} data-testid={`card-board-task-${task.id}`}><div className="flex items-start gap-2"><GripVertical size={15} className="mt-0.5 shrink-0 text-muted-foreground/50" /><button onClick={() => setModal({ open: true, task })} className="min-w-0 flex-1 text-left" data-testid={`button-board-edit-${task.id}`}><p className="text-sm font-bold">{task.title}</p><div className="mt-3 flex flex-wrap items-center gap-2">{project && <span className="flex items-center gap-1 text-[10px] text-muted-foreground"><span className="size-1.5 rounded-full" style={{ backgroundColor: project.color }} />{project.name}</span>}<PriorityPill priority={task.priority} /></div></button></div></article>; })}</div>
      {!byStatus[column.id].length && <div className="mt-2 rounded-xl border border-dashed border-border p-8 text-center text-xs text-muted-foreground">Drop a task here</div>}
    </section>)}</div>
    <TaskModal open={modal.open} task={modal.task} initialDate="" onClose={() => setModal({ open: false })} />
  </div>;
}