import { useEffect, useMemo, useState } from 'react';
import { ArrowUpRight, CalendarClock, Plus, Target } from 'lucide-react';
import { Link } from 'wouter';
import { useProductivity, todayKey, type Task } from '@/context/ProductivityContext';
import { EmptyState, PageIntro, SectionHeader, StatCard, TaskRow } from '@/components/WorkspaceUI';
import { TaskModal } from '@/components/TaskModal';

export default function Dashboard() {
  const { tasks, goals, sessions } = useProductivity();
  const [modal, setModal] = useState<{ open: boolean; task?: Task | null }>({ open: false });
  useEffect(() => {
    const open = () => setModal({ open: true });
    window.addEventListener('solstice:add-task', open);
    return () => window.removeEventListener('solstice:add-task', open);
  }, []);
  const today = todayKey();
  const openTasks = tasks.filter((task) => task.status !== 'done');
  const todayTasks = tasks.filter((task) => task.dueDate === today && task.status !== 'done');
  const done = tasks.filter((task) => task.status === 'done').length;
  const rate = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
  const upcoming = useMemo(() => [...openTasks].sort((a, b) => a.dueDate.localeCompare(b.dueDate)).slice(0, 4), [openTasks]);
  const greeting = new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 18 ? 'Good afternoon' : 'Good evening';

  return <div>
    <PageIntro eyebrow={new Date().toLocaleDateString('en', { weekday: 'long', month: 'long', day: 'numeric' })} title={`${greeting}, Mara.`} description="A clear little landing place for the things that matter today." action={<button onClick={() => setModal({ open: true })} className="flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-sm hover:brightness-105" data-testid="button-dashboard-add-task"><Plus size={17} /> Add a task</button>} />
    <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <StatCard label="For today" value={todayTasks.length} detail={todayTasks.length ? 'A focused handful' : 'Nothing pressing' } tone="teal" />
      <StatCard label="Open tasks" value={openTasks.length} detail={`${tasks.length} total in your workspace`} />
      <StatCard label="Completion rate" value={`${rate}%`} detail={rate > 50 ? 'Momentum is on your side' : 'One small win at a time'} tone="warm" />
      <StatCard label="Focus sessions" value={sessions[today] ?? 0} detail="Completed today" />
    </section>
    <div className="mt-8 grid gap-8 xl:grid-cols-[1.35fr_.65fr]">
      <section><SectionHeader title="Your next moves" action={<Link href="/tasks" className="flex items-center gap-1 text-xs font-bold text-primary hover:underline" data-testid="link-view-all-tasks">View all <ArrowUpRight size={14} /></Link>} />{upcoming.length ? <div className="space-y-3">{upcoming.map((task) => <TaskRow key={task.id} task={task} onEdit={(selected) => setModal({ open: true, task: selected })} />)}</div> : <EmptyState title="The runway is clear" description="Add a task when something worth your attention arrives." action={<button onClick={() => setModal({ open: true })} className="rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground" data-testid="button-empty-add-task">Add your first task</button>} />}</section>
      <div className="space-y-8">
        <section><SectionHeader title="Today, gently" /><div className="rounded-2xl bg-sidebar p-5 text-sidebar-foreground"><div className="flex items-start justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.16em] text-sidebar-primary">Daily rhythm</p><p className="mt-3 font-display text-2xl">{todayTasks.length ? `${todayTasks.length} things in view` : 'A quiet day ahead'}</p></div><CalendarClock className="text-sidebar-primary" size={22} /></div><div className="mt-7 h-2 overflow-hidden rounded-full bg-sidebar-accent"><div className="h-full rounded-full bg-sidebar-primary transition-all" style={{ width: `${tasks.filter((task) => task.dueDate === today && task.status === 'done').length / Math.max(1, tasks.filter((task) => task.dueDate === today).length) * 100}%` }} /></div><p className="mt-3 text-xs opacity-60">Your pace is allowed to be human.</p></div></section>
        <section><SectionHeader title="In motion" action={<Link href="/goals" className="text-xs font-bold text-primary hover:underline" data-testid="link-view-goals">All goals</Link>} />{goals.length ? <div className="space-y-3">{goals.slice(0, 3).map((goal) => <div key={goal.id} className="rounded-2xl border border-border bg-card p-4" data-testid={`card-goal-${goal.id}`}><div className="flex items-start justify-between gap-4"><div><p className="text-sm font-bold">{goal.title}</p><p className="mt-1 text-xs text-muted-foreground">{goal.current} of {goal.target} complete</p></div><Target size={17} style={{ color: goal.color }} /></div><div className="mt-4 h-2 rounded-full bg-muted"><div className="h-full rounded-full" style={{ width: `${Math.min(100, goal.current / goal.target * 100)}%`, backgroundColor: goal.color }} /></div></div>)}</div> : <EmptyState title="Name what matters" description="Goals give your week a quiet north star." />}</section>
      </div>
    </div>
    <TaskModal open={modal.open} task={modal.task} onClose={() => setModal({ open: false })} />
  </div>;
}