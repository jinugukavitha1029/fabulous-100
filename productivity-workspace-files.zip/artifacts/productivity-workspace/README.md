# Solstice — Personal Productivity Workspace

Solstice is a calm, local-first home base for tasks, projects, goals, deadlines, analytics, and focus sessions. It uses the browser's `localStorage`; there is no backend or account required.

## Run locally

```bash
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## Build

```bash
npm run build
```

## Included

- Dashboard overview with local demo data on first visit
- Task creation, editing, deletion, completion, filters, sorting, projects, priorities, and due dates
- Independent native drag-and-drop Kanban board
- Month calendar with selected-day task details and add-from-date
- Goals with progress tracking
- Recharts completion, project, session, and goal views
- Configurable Pomodoro focus room with notification permission support
- Light/evening theme, project creation, local reset controls, and mobile navigation